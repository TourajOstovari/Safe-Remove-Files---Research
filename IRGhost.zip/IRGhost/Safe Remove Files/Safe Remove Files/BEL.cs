﻿using System.Collections.Generic;
using System.Linq;
using System.Collections;
namespace Safe_Remove_Files
{
    public class BEL
    {
        static int size;
        public BEL(int Size)
        {
            size = Size;
            lst = new List<long>();
        }

        public List<long> lst;

        /// <summary>
        /// BEL Random Number Generator for Binary Mode
        /// </summary>
        public void BEL_(int seed_, int shift_,int q_=9,int p_=1000,int m_=20,int c_=10,int a_=66,int b_=55,int key1=44,int key2=12,int key3=11,int key4=4741)
        {
            int seed = seed_;
            int shift = shift_;
            int q = q_;
            int p = p_;
            int m = m_;
            int c = c_;
            int a = a_;
            int b = b_;

            int keyBinary = key1;
            int keyBinary_2 = key2;
            int keyBinary_3 = keyBinary ^ keyBinary_2 ^ seed;

            int keyBinary_4 = key3;

            int keyBinary_5 = key4;


            {
                var sha512 = System.Security.Cryptography.SHA512.Create();
                byte[] temps = sha512.ComputeHash(System.Text.Encoding.ASCII.GetBytes(seed.ToString()));
                int sums = 0;
                for (int i = 0; i < temps.Length; i++)
                {
                    sums += temps[i];
                }

                seed = Math.Abs(seed ^ a + b) ^ c;

                seed = (keyBinary ^ keyBinary_2 ^ keyBinary_3 & keyBinary_4 ^ sums) & seed;
            }




            


            bool Time1 = true;
            bool Time2 = true;
            bool Time3 = false;

            bool Time4 = false;



            int S1 = 0;
            int size_counter = size;

            for (int i = 1; i <= 1; i++)
            {

                if (Time2 == false)
                {
                    S1 = (((((seed * shift ^ p) + m) + q) + size) + (int)(Math.Pow(m, 3) % seed)) ^ c;
                }
                else
                {
                    S1 = (((seed ^ shift & p) ^ m) ^ (q * size)) + (int)(Math.Pow(m, 3) * seed) ^ c;

                }

                lst.Add(S1);

                size_counter--;

                for (int i2 = (shift ^ seed) + size; i2 > 0; i2--)
                {
                    keyBinary_4 = S1 ^ shift ^ seed;

                    if (Time1 == false && Time3 == false)
                    {
                        m = (m + i2) ^ size;
                        q = Math.Abs((p & m) + shift ^ size) ^ seed;
                        shift = (shift + 2) ^ size;
                        p = Math.Abs((q ^ m) - shift ^ size) ^ keyBinary_3;
                        seed = (seed * shift + m) ^ c ^ keyBinary_4;
                    }
                    else
                    {
                        m = q ^ size ^ i2 ^ shift;
                        q = (int)Math.Abs((p & m) + shift ^ size) ^ c ^ keyBinary_3;
                        p = (int)Math.Abs((q | m) + shift ^ size) ^ c ^ seed ^ keyBinary_4;
                        shift = (shift + 1) ^ size ^ (seed ^ keyBinary_4);
                        seed = (int)(seed * shift + m) ^ (int)m ^ b ^ keyBinary_4;
                    }
                    if (Time3 == false && Time1 == true)
                        seed = (Math.Abs(((seed * q + m) ^ 3 ^ c) + shift + p * q) ^ c) ^ keyBinary_3 ^ keyBinary_4;



                    keyBinary_3 = ((keyBinary_3 ^ shift) ^ seed) ^ i2;
                    c = c ^ size ^ shift;
                    q = q ^ c;
                    p = c = q ^ c;
                    a = a ^ q;
                    m = shift ^ m ^ a;

                    shift = b = seed ^ b;

                    seed = seed ^ keyBinary ^ b ^ c ^ a;
                    keyBinary = keyBinary ^ m ^ seed ^ q ^ p;
                    seed = keyBinary_2 ^ seed;
                    keyBinary_2 = (keyBinary ^ c) ^ keyBinary_2 ^ i2;

                    keyBinary_4 = m ^ c ^ keyBinary_3;




                    if (Time2 == false)
                    {
                        seed = (((((seed ^ shift ^ p ^ keyBinary_4) + m ^ keyBinary_3) + q) + size) ^ (int)(Math.Pow(m, 3) % seed)) ^ c ^ keyBinary;
                    }
                    else
                    {
                        seed = (((seed ^ shift & p) ^ m) ^ (q * size) ^ keyBinary_2) + (int)(Math.Pow(keyBinary_4 ^ m, keyBinary ^ 2) * seed) ^ c ^ keyBinary_2;

                    }

                    keyBinary_3 = (((keyBinary_3 ^ seed) ^ p) ^ i2) ^ q;


                    var sha512 = System.Security.Cryptography.SHA512.Create();
                    byte[] temps = sha512.ComputeHash(System.Text.Encoding.ASCII.GetBytes(seed.ToString()));
                    int sums = 0;
                    for (int i3 = 0; i3 < temps.Length; i3++)
                    {
                        sums += temps[i3];
                    }





                    seed = seed ^ keyBinary_3 ^ sums;


                    keyBinary = keyBinary ^ sums;
                    keyBinary_2 = keyBinary_2 ^ sums;
                    keyBinary_3 = keyBinary_3 ^ sums;
                    keyBinary_4 = keyBinary_4 ^ sums;

                    int sums_ = 0;
                    seed = keyBinary ^ keyBinary_2 ^ keyBinary_4;
                    if ((Time3 == false && Time1 == true))
                    {
                        var sha256 = System.Security.Cryptography.SHA256.Create();
                        byte[] temps_ = sha512.ComputeHash(System.Text.Encoding.ASCII.GetBytes((seed * p + q).ToString()));

                        for (int i3 = 0; i3 < temps.Length; i3++)
                        {
                            sums_ += temps_[i];
                            sums ^= temps_[i];
                        }

                        seed = Math.Abs(seed ^ q + sums_) ^ m;
                        keyBinary_5 = (keyBinary_5 ^ sums) ^ sums_;

                    }
                    seed = (seed ^ sums_) ^ keyBinary_5;
                    Time1 = !Time1;
                    Time2 = !Time2;
                    if (shift % 2 == 0 || m % 2 == 00)
                    {
                        Time3 = !Time3;
                    }

                    if (seed % 2 == 0 && (sums % 2 == 0 || sums_ % 2 == 0))
                    {
                        {
                            lst.Add(sums);
                        }

                    }
                    else
                    {
                        {
                            lst.Add(sums);
                        }

                    }
                    Time4 = !Time4;
                    size_counter--;
                    if (size_counter == 0)
                        break;
                }

            }
            //
            
            foreach (var item in lst)
            { 
                System.IO.File.AppendAllText(@"D:\rand.txt",item.ToString()+"\n");
            }
            
        }
    }
}
