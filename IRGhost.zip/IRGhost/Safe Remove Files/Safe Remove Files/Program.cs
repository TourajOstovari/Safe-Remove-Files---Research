﻿// ODESSA512 - HASH                  BEL BIT GENERATOR
using static System.Console;
using Safe_Remove_Files;
using System.Linq;
Console.WriteLine("Hello, It is developed by Mr. Touraj Ostovari!");
Title = "IRGhost - Erase files with safaty";
WriteLine("Enter File Address: ");
string adrs = Console.ReadLine();
long Sum_ = 0;
byte[] bytes = Odessa_512_hash_function.Class1.Generator(null, System.IO.File.ReadAllBytes(adrs));
Clear();
for (int i = 0; i < bytes.Length; i++)
{
    Sum_ += bytes[i];
}
{
    byte[] temps_ = System.IO.File.ReadAllBytes(adrs);

    {
        for (int i2 = 1; i2 < 12; i2++)
        {



            // Step 1
            {
                BEL bl = new BEL(temps_.Length);
                bl.BEL_((int)Sum_ * (i2*3), temps_.Length);
                for (int i = 0; i < temps_.Length; i++)
                {
                    temps_[i] = (byte)(temps_[i] ^ (bl.lst[i]));
                }
            }

            // Saving File
            System.IO.File.WriteAllBytes(adrs, temps_);

            // Step 2
            {
                BEL bl = new BEL(temps_.Length);
                bl.BEL_((int)Sum_, temps_.Length);
                for (int i = 0; i < temps_.Length; i++)
                {
                    temps_[i] = (byte)(temps_[i] & (int)bl.lst[i]);
                }
            }

            // Saving File
            System.IO.File.WriteAllBytes(adrs, temps_);

            // Step 3
            {
                BEL bl = new BEL(temps_.Length);
                bl.BEL_((int)(Sum_ *(i2*2)), temps_.Length);
                for (int i = 0; i < temps_.Length; i++)
                {
                    temps_[i] = (byte)(temps_[i] ^ (int)bl.lst[i]);
                }
            

            // Saving File
            System.IO.File.WriteAllBytes(adrs, temps_);


            // Step 4
            

                for (int i = 0; i < temps_.Length; i++)
                {
                    temps_[i] = (byte)(bl.lst[i]);
                }
            }

            // Saving File
            System.IO.File.WriteAllBytes(adrs, temps_);

            // Step 5
            {

                for (int i = 0; i < temps_.Length; i++)
                {
                    temps_[i] = ((int)1);
                }
            }
            // Saving File
            System.IO.File.WriteAllBytes(adrs, temps_);


            // Step 6
            {

                for (int i = 0; i < temps_.Length; i++)
                {
                    temps_[i] = 0;
                }
            }

            // Saving File
            System.IO.File.WriteAllBytes(adrs, temps_);
        }
    }
}
